#include "mensagem.h"

int main(int argc, char *argv[])
{
	
	
	
	system("mode con:cols=105 lines=30");
	ListaDePacientes *lista = NULL;
	char nome[50];
	char nome2[50];
	char endereco[50];
	int telefone = 0;
	int escolhaDeMenu = 9;
	Paciente paciente;


    paciente.nome = "Carlos";
    paciente.idade = 24;
    paciente.medico = "Fabo";
    paciente.endereco = "Popular";
    paciente.telefone = 900900900;
    lista = criarLista(lista);

    lista = inserirPaciente(lista, paciente);
    
 	 Paciente paciente2;
    paciente2.nome = "Jose";
    paciente2.idade = 24;
    paciente2.medico = "Fabio";
    paciente2.endereco = "Popular";
    paciente2.telefone = 97900900;
    lista = inserirPaciente(lista, paciente2);
    
    Paciente paciente4;
    paciente4.nome = "Cirilo";
    paciente4.idade = 24;
    paciente4.medico = "Fabio";
    paciente4.endereco = "Popular";
    paciente4.telefone = 940900900;
    lista = inserirPaciente(lista, paciente4);
    
    Paciente paciente3;
    paciente3.nome = "Luisa";
    paciente3.idade = 24;
    paciente3.medico = "Fabio";
    paciente3.endereco = "Popular";
    paciente3.telefone = 910900900;
    lista = inserirPaciente(lista, paciente3);
    
    Paciente paciente7;
    paciente7.nome = "Trindade";
    paciente7.idade = 24;
    paciente7.medico = "Fabio";
    paciente7.endereco = "Popular";
    paciente7.telefone = 910900900;
    lista = inserirPaciente(lista, paciente7);
    
    Paciente paciente6;
    paciente6.nome = "Aurea";
    paciente6.idade = 24;
    paciente6.medico = "Fabo";
    paciente6.endereco = "Popular";
    paciente6.telefone = 930900900;
    lista = inserirPaciente(lista, paciente6);
    
  
	do
	{
		switch(escolhaDeMenu)
		{
			
			case 1:
				system("cls");
				lista = criarLista(lista);
				apresentarMensagemListaInicializada();
				escolhaDeMenu = 9;
				system("pause > null");
				break;
			case 9:
				
				apresentarTelaIncial();
				scanf("%d", &escolhaDeMenu);
				break;
			case 2:
				system("cls");
				if(verificarListaVazia(lista))
				{ 
					apresentarMensagemListaVazia();
				}
				else
				{
					apresentarMensagemListaComElementos(contarPacientesNaLista(lista));
					
					apresentarLista(lista);
				}
				escolhaDeMenu = 9;
				
				break;
			case 3:
				system("cls");
				printf("Nome: ");
				fflush(stdin);
				gets(nome);
				paciente.nome = nome;
				printf("Idade: ");
				scanf("%d", &paciente.idade);
				printf("Telefone: ");
				scanf("%d", &paciente.telefone);
				printf("Endereco: ");
				fflush(stdin);
				gets(endereco);
				paciente.endereco = endereco;
				printf("Medico: ");
				fflush(stdin);
				gets(nome2);
				paciente.medico = nome2;
				lista = inserirPaciente(lista, paciente);
				escolhaDeMenu = 9;
				
				break;		
			case 4:
				printf("Nome: ");
				fflush(stdin);
				gets(nome);
				lista = removerPaciente(lista, nome);	
				apresentarLista(lista);	
			case 5:
				printf("Paciente a substituir: ");
				fflush(stdin);
				gets(nome);
				printf("Paciente que vai substituir: ");
				fflush(stdin);
				gets(nome2);			
				substituirPaciente(lista, nome, nome2);
				escolhaDeMenu = 9;
				break;
			case 6:
				printf("Telefone: ");
				scanf("%d", &telefone);
				actualizarPaciente(lista, telefone);
				escolhaDeMenu = 9;
				break;
			case 7:
				printf("Medico: ");
				fflush(stdin);
				gets(nome);
				apresentarMensagemPacientesComMesmoMedico(pacientesComOMesmoMedico(lista, nome));
				break;
			default:
				escolhaDeMenu = 9;
		}
				
	}while(escolhaDeMenu != 0);  

    
    
	return 0;
}
