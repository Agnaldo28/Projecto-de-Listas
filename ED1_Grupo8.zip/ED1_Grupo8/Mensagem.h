#include <windows.h>
#include"ListaDePacientes.h"

typedef enum  
{
	VERMELHO = 4,
	
	DOURADO = 6,//1,
	VERDE = 2,
	BRANCO_CLARO = 15,
	BRANCO = 15, //15 8 7
 	TABELA_CLARA = 246,
	TABELA_AZUL = 7,
	TABELA_ESCURA = 112,
	TABELA_CINZA = 128,
	TABELA_DOURADA = 110	
}COR;


void apresentarMensagemPacientesComMesmoMedico(int medicos);
void apresentarMensagemListaInicializada();
void apresentarMensagemTabelaVazia();
void mostraCursor(int mostrar);
void alterarCorDaConsola(COR cor);
void apresentarMensagem();
void telaIncial();
void apresentarLista(ListaDePacientes *lista);
