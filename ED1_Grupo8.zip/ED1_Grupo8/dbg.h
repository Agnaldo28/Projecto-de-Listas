/*#ifndef __dbg_h__
#define __dbg_h__ 
#include<stdio.h>
#include<errno.h>
#include<string.h>
#include<stdlib.h>

#ifdef SEMDEBUG
    #define debug(M, ...)
#else
    #define debug(M, ...) fprintf(stderr, "DEGUG %s:%d: " M "\n", \
        __FILE__, __LINE__, ##__VA_ARGS__)
#endif

#define limparErrno() (errno == 0 ? "Nenhum" : strerror(errno))

#define logErro(M, ...) fprintf(stderr, "[ERRO] (%s:%d: erro: %s) " M "\n", __FILE__, __LINE__,\
                                 limpaErrno(), ##__VA_ARGS__)

#define logAviso(M, ...) fprintf(stderr, "[AVISO] (%s:%d: erro: %s) " M "\n", __FILE__, __LINE__,\
                                 limpaErrno(), ##__VA_ARGS__)

#define logInformacao(M, ...) fprintf(stderr, "[INFO] (%s:%d: %s) " M "\n", __FILE__, __LINE__,\
                                 limpaErrno(), ##__VA_ARGS__)

#define verifica(A, M, ...) if(!(A)) \
{\
    logErro(M, ##__VA_ARGS__);\
    errno = 0;\
   /*goto error;*/\ */
/*}


#define sentinela(M, ...) { logErro(M, __VA_ARGS__);\
    /*goto error;*/}


#define verificarMemoria(A) verifica((A), "Memoria Insuficiente!")

#define verificaDebug(A, M, ...) if((!A)) { debug(M, ##__VA_ARGS__);\
        errno = 0; /*goto error;*/}
#endif // __dbg_h__  */




